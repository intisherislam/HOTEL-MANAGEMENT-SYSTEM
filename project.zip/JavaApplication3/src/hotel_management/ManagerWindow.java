/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package hotel_management;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author cyr0x
 */
public class ManagerWindow extends javax.swing.JPanel {

    private String user = "";

    /**
     * Creates new form Window
     *
     * @param username
     */
    public ManagerWindow(String username) {
        initComponents();
        this.user = username;
        guest_table.setName("guest_table");
        guest_table_checkout.setName("guest_table_checkout");
        room_table.setName("room_table");
        log_table.setName("log_table");
        loadGuests(guest_table);
        loadGuests(guest_table_checkout);
        loadAvailableRooms();
        loadLogs();
        refreshRoomTable();
    }

    // Generic search method
    public void searchTable(javax.swing.JTable table, String searchText) {
        if (searchText == null || searchText.isEmpty()) {
            // Reload original data
            if ("guest_table".equals(table.getName())) {
                loadGuests(guest_table);
            } else if ("guest_table_checkout".equals(table.getName())) {
                loadGuests(guest_table_checkout);
            }
            return;
        }

        DefaultTableModel model = (DefaultTableModel) table.getModel();
        DefaultTableModel filteredModel = new DefaultTableModel();

        // Copy column names
        for (int i = 0; i < model.getColumnCount(); i++) {
            filteredModel.addColumn(model.getColumnName(i));
        }

        String lowerSearch = searchText.toLowerCase();

        // Filter rows
        for (int i = 0; i < model.getRowCount(); i++) {
            boolean matches = false;
            for (int j = 0; j < model.getColumnCount(); j++) {
                Object value = model.getValueAt(i, j);
                if (value != null && value.toString().toLowerCase().contains(lowerSearch)) {
                    matches = true;
                    break;
                }
            }
            if (matches) {
                Object[] rowData = new Object[model.getColumnCount()];
                for (int k = 0; k < model.getColumnCount(); k++) {
                    rowData[k] = model.getValueAt(i, k);
                }
                filteredModel.addRow(rowData);
            }
        }

        table.setModel(filteredModel);
    }

    // Load all guests into guest_table
    public void loadGuests(javax.swing.JTable table) {
        String query = "SELECT g.id, g.fullname, r.room_no, g.phone_no, g.checkin_date, g.checkout_date "
                + "FROM guests g JOIN rooms r ON g.room_no = r.room_no ";

        if ("guest_table_checkout".equals(table.getName())) {
            query += "WHERE checkout_date IS NULL";
        }

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(query); ResultSet rs = pst.executeQuery()) {

            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0); // clear existing rows

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("fullname");
                String roomNo = rs.getString("room_no");
                String phone = rs.getString("phone_no");
                String checkIn = rs.getDate("checkin_date").toString();
                String checkOut = rs.getDate("checkout_date") == null ? "Staying" : rs.getDate("checkout_date").toString();

                model.addRow(new Object[]{id, name, roomNo, phone, checkIn, checkOut});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading guests: " + e.getMessage());
        }
    }

    public void loadAvailableRooms() {
        String query = "SELECT room_no, rent_per_night FROM rooms WHERE status = 'available'";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(query); ResultSet rs = pst.executeQuery()) {

            drop_room.removeAllItems(); // clear previous items

            while (rs.next()) {
                String roomNo = rs.getString("room_no");
                double rent = rs.getDouble("rent_per_night");
                drop_room.addItem(roomNo);

                // Store the rent as a client property of the combo item for easy retrieval
                drop_room.putClientProperty(roomNo, rent);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading rooms: " + e.getMessage());
        }

        // Set action listener to update jLabel8 when a room is selected
        drop_room.addActionListener(e -> {
            String selectedRoom = (String) drop_room.getSelectedItem();
            if (selectedRoom != null) {
                Object rentValue = drop_room.getClientProperty(selectedRoom);
                if (rentValue != null) {
                    jLabel8.setText(String.valueOf(rentValue));
                } else {
                    jLabel8.setText("0");
                }
            }
        });
    }

    public void registerGuest() {
        String fullName = full_name.getText().trim();
        String phone = phone_no.getText().trim();
        java.util.Date checkin = checkin_date.getDate();
        String roomNo = (String) drop_room.getSelectedItem();

        if (fullName.isEmpty() || roomNo == null || checkin == null) {
            JOptionPane.showMessageDialog(null, "Please fill in all required fields!");
            return;
        }

        java.sql.Date checkinSqlDate = new java.sql.Date(checkin.getTime());

        String insertGuestQuery = "INSERT INTO guests (fullname, room_no, phone_no, checkin_date) VALUES (?, ?, ?, ?)";
        String updateRoomQuery = "UPDATE rooms SET status = 'occupied' WHERE room_no = ?";
        String logQuery = "INSERT INTO logs (log_date, log_time, action) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstGuest = conn.prepareStatement(insertGuestQuery); PreparedStatement pstRoom = conn.prepareStatement(updateRoomQuery); PreparedStatement pstLog = conn.prepareStatement(logQuery)) {

            conn.setAutoCommit(false); // start transaction

            // Insert guest
            pstGuest.setString(1, fullName);
            pstGuest.setString(2, roomNo);
            pstGuest.setString(3, phone);
            pstGuest.setDate(4, checkinSqlDate);
            pstGuest.executeUpdate();

            // Update room status
            pstRoom.setString(1, roomNo);
            pstRoom.executeUpdate();

            // Insert log
            LocalDateTime now = LocalDateTime.now();
            String date = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            String time = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
            String action = "Registered Guest " + fullName + " in Room " + roomNo + " by " + this.user;

            pstLog.setString(1, date);
            pstLog.setString(2, time);
            pstLog.setString(3, action);
            pstLog.executeUpdate();

            conn.commit(); // commit transaction

            JOptionPane.showMessageDialog(null, "Guest registered successfully!");
            full_name.setText("");
            phone_no.setText("");
            checkin_date.setDate(null);
            drop_room.setSelectedIndex(0);

            // Refresh tables
            refreshRoomTable();
            loadGuests(guest_table); // you should implement a method to load guests into guest_table
            loadLogs();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error registering guest: " + e.getMessage());
        }
    }

    public void addRoom() {
        String roomNo = room_no.getText().trim();
        String rentStr = rent.getText().trim();

        if (roomNo.isEmpty() || rentStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter Room No and Rent!");
            return;
        }

        try {
            double cost = Double.parseDouble(rentStr);

            String query = "INSERT INTO rooms (room_no, rent_per_night) VALUES (?, ?)";
            try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(query)) {

                pst.setString(1, roomNo);
                pst.setDouble(2, cost);

                pst.executeUpdate();

                // Insert into logs
                String logQuery = "INSERT INTO logs (log_date, log_time, action) VALUES (?, ?, ?)";
                try (PreparedStatement logStmt = conn.prepareStatement(logQuery)) {
                    LocalDateTime now = LocalDateTime.now();
                    String date = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    String time = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
                    String action = "Added Room " + roomNo + " with rent " + cost + " by " + this.user;

                    logStmt.setString(1, date);
                    logStmt.setString(2, time);
                    logStmt.setString(3, action);

                    logStmt.executeUpdate();
                }

                JOptionPane.showMessageDialog(null, "Room added successfully!");
                room_no.setText("");
                rent.setText("");

                refreshRoomTable();
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Rent must be a valid number!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error adding room: " + e.getMessage());
        }
    }

    // Refresh Room Table
    public void refreshRoomTable() {
        String query = "SELECT room_no, rent_per_night, status FROM rooms";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(query); ResultSet rs = pst.executeQuery()) {

            DefaultTableModel model = (DefaultTableModel) room_table.getModel();
            model.setRowCount(0); // clear existing rows

            while (rs.next()) {
                String roomNo = rs.getString("room_no");
                double rent = rs.getDouble("rent_per_night");
                String status = rs.getString("status");

                model.addRow(new Object[]{roomNo, rent, status});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error refreshing rooms: " + e.getMessage());
        }
    }

    public void checkout() {
        // Get selected row from guest_table_checkout
        int selectedRow = guest_table_checkout.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a guest to checkout!");
            return;
        }

        // Get guest data from the selected row
        int guestId = (int) guest_table_checkout.getValueAt(selectedRow, 0);
        String guestName = (String) guest_table_checkout.getValueAt(selectedRow, 1);
        String roomNo = (String) guest_table_checkout.getValueAt(selectedRow, 2);
        String checkinDateStr = (String) guest_table_checkout.getValueAt(selectedRow, 4);

        // Get room rent and calculate total
        String getRoomRentQuery = "SELECT rent_per_night FROM rooms WHERE room_no = ?";
        String getCheckinDateQuery = "SELECT checkin_date FROM guests WHERE id = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstRent = conn.prepareStatement(getRoomRentQuery); PreparedStatement pstCheckin = conn.prepareStatement(getCheckinDateQuery)) {

            // Get room rent
            pstRent.setString(1, roomNo);
            ResultSet rsRent = pstRent.executeQuery();

            double rentPerNight = 0;
            if (rsRent.next()) {
                rentPerNight = rsRent.getDouble("rent_per_night");
            }

            // Get checkin date
            pstCheckin.setInt(1, guestId);
            ResultSet rsCheckin = pstCheckin.executeQuery();

            java.sql.Date checkinDate = null;
            if (rsCheckin.next()) {
                checkinDate = rsCheckin.getDate("checkin_date");
            }

            // Calculate number of nights stayed
            LocalDateTime checkoutDateTime = LocalDateTime.now();
            java.sql.Date checkoutDate = java.sql.Date.valueOf(checkoutDateTime.toLocalDate());

            long diffInMillies = Math.abs(checkoutDate.getTime() - checkinDate.getTime());
            long nightsStayed = diffInMillies / (1000 * 60 * 60 * 24);

            // Ensure at least 1 night is charged
            if (nightsStayed == 0) {
                nightsStayed = 1;
            }

            // Calculate total rent
            double totalRent = rentPerNight * nightsStayed;

            // Update guest checkout date
            String updateGuestQuery = "UPDATE guests SET checkout_date = ? WHERE id = ?";
            // Update room status to available
            String updateRoomQuery = "UPDATE rooms SET status = 'available' WHERE room_no = ?";
            // Insert log
            String logQuery = "INSERT INTO logs (log_date, log_time, action) VALUES (?, ?, ?)";

            try (PreparedStatement pstUpdateGuest = conn.prepareStatement(updateGuestQuery); PreparedStatement pstUpdateRoom = conn.prepareStatement(updateRoomQuery); PreparedStatement pstLog = conn.prepareStatement(logQuery)) {

                conn.setAutoCommit(false); // start transaction

                // Update guest checkout date
                pstUpdateGuest.setDate(1, checkoutDate);
                pstUpdateGuest.setInt(2, guestId);
                pstUpdateGuest.executeUpdate();

                // Update room status
                pstUpdateRoom.setString(1, roomNo);
                pstUpdateRoom.executeUpdate();

                // Insert log
                String date = checkoutDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                String time = checkoutDateTime.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
                String action = "Checked out Guest " + guestName + " from Room " + roomNo
                        + " - Nights: " + nightsStayed + ", Total: $" + String.format("%.2f", totalRent)
                        + " by " + this.user;

                pstLog.setString(1, date);
                pstLog.setString(2, time);
                pstLog.setString(3, action);
                pstLog.executeUpdate();

                conn.commit(); // commit transaction

                // Show success message with checkout details
                String message = String.format(
                        "Checkout Successful!\n\n"
                        + "Guest: %s\n"
                        + "Room: %s\n"
                        + "Nights Stayed: %d\n"
                        + "Rent per Night: $%.2f\n"
                        + "Total Amount: $%.2f",
                        guestName, roomNo, nightsStayed, rentPerNight, totalRent
                );

                JOptionPane.showMessageDialog(null, message, "Checkout Successful", JOptionPane.INFORMATION_MESSAGE);

                // Refresh tables
                loadGuests(guest_table_checkout);
                refreshRoomTable();
                loadLogs();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error during checkout: " + e.getMessage());
        }
    }

    public void loadLogs() {
        String query = "SELECT log_date, log_time, action FROM logs ORDER BY id DESC"; // latest logs first

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(query); ResultSet rs = pst.executeQuery()) {

            DefaultTableModel model = (DefaultTableModel) log_table.getModel();
            model.setRowCount(0); // clear existing rows

            while (rs.next()) {
                String date = rs.getString("log_date");
                String time = rs.getString("log_time");
                String action = rs.getString("action");

                model.addRow(new Object[]{date, time, action});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading logs: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logs_tab = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        guest_table = new javax.swing.JTable();
        searchText = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        full_name = new javax.swing.JTextField();
        phone_no = new javax.swing.JTextField();
        checkin_date = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        drop_room = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnRegister = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        roomRefresh = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        room_table = new javax.swing.JTable();
        room_no = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        rent = new javax.swing.JTextField();
        btnAddRoom = new javax.swing.JButton();
        btnRefreshRoom = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        guest_table_checkout = new javax.swing.JTable();
        searchText1 = new javax.swing.JTextField();
        btnSearch1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnCheckout = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        log_table = new javax.swing.JTable();
        btnRefreshLogs = new javax.swing.JButton();

        guest_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Room No", "Phone No", "Check In", "Check Out"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(guest_table);
        if (guest_table.getColumnModel().getColumnCount() > 0) {
            guest_table.getColumnModel().getColumn(0).setResizable(false);
            guest_table.getColumnModel().getColumn(1).setResizable(false);
            guest_table.getColumnModel().getColumn(2).setResizable(false);
            guest_table.getColumnModel().getColumn(3).setResizable(false);
            guest_table.getColumnModel().getColumn(4).setResizable(false);
            guest_table.getColumnModel().getColumn(5).setResizable(false);
        }

        btnSearch.setText("Search");
        btnSearch.addActionListener(this::btnSearchActionPerformed);

        jLabel4.setFont(new java.awt.Font("Liberation Sans", 0, 24)); // NOI18N
        jLabel4.setText("Register New Guest");

        jLabel1.setText("Full Name");

        drop_room.addActionListener(this::drop_roomActionPerformed);

        jLabel3.setText("Room No");

        jLabel5.setText("Phone No");

        jLabel6.setText("Check In");

        btnRegister.setText("Register New Guest");
        btnRegister.addActionListener(this::btnRegisterActionPerformed);

        jLabel7.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        jLabel7.setText("Rent Per Night:");

        jLabel8.setFont(new java.awt.Font("Liberation Sans", 1, 24)); // NOI18N
        jLabel8.setText("0");

        jButton1.setText("Refresh Table");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        roomRefresh.setText("Refresh");
        roomRefresh.addActionListener(this::roomRefreshActionPerformed);

        jLabel10.setText("Search By Phone Number");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnRegister)
                                    .addComponent(full_name, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(checkin_date, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(drop_room, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(roomRefresh))
                                        .addComponent(phone_no, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addComponent(jLabel4)))
                        .addGap(47, 47, 47))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(searchText, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSearch))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addContainerGap(10, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(jLabel1)
                            .addComponent(full_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(jLabel3)
                            .addComponent(drop_room, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roomRefresh))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(jLabel5)
                            .addComponent(phone_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(checkin_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addComponent(btnRegister)
                        .addGap(112, 112, 112)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(jLabel8)
                            .addComponent(jButton1)
                            .addComponent(jLabel7)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSearch))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        logs_tab.addTab("Manage Guests", jPanel1);

        room_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Room No", "Rent Per Night", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(room_table);
        if (room_table.getColumnModel().getColumnCount() > 0) {
            room_table.getColumnModel().getColumn(0).setResizable(false);
            room_table.getColumnModel().getColumn(1).setResizable(false);
            room_table.getColumnModel().getColumn(2).setResizable(false);
        }

        jLabel2.setText("Room No");

        jLabel9.setText("Rent Per Night");

        btnAddRoom.setText("Add Room");
        btnAddRoom.addActionListener(this::btnAddRoomActionPerformed);

        btnRefreshRoom.setText("Refresh");
        btnRefreshRoom.addActionListener(this::btnRefreshRoomActionPerformed);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(room_no, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(rent, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnAddRoom, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnRefreshRoom, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(room_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel9)
                    .addComponent(rent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddRoom)
                    .addComponent(btnRefreshRoom))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        logs_tab.addTab("Manage Rooms", jPanel3);

        guest_table_checkout.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Room No", "Phone No", "Check In"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(guest_table_checkout);
        if (guest_table_checkout.getColumnModel().getColumnCount() > 0) {
            guest_table_checkout.getColumnModel().getColumn(0).setResizable(false);
            guest_table_checkout.getColumnModel().getColumn(1).setResizable(false);
            guest_table_checkout.getColumnModel().getColumn(2).setResizable(false);
            guest_table_checkout.getColumnModel().getColumn(3).setResizable(false);
            guest_table_checkout.getColumnModel().getColumn(4).setResizable(false);
        }

        btnSearch1.setText("Search");
        btnSearch1.addActionListener(this::btnSearch1ActionPerformed);

        jButton2.setText("Refresh Table");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        btnCheckout.setText("Procced To Checkout");
        btnCheckout.addActionListener(this::btnCheckoutActionPerformed);

        jLabel11.setText("Search By Phone Number");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(searchText1)
                                .addGap(18, 18, 18)
                                .addComponent(btnSearch1))
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2)
                            .addComponent(btnCheckout)))
                    .addComponent(jLabel11))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnCheckout)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchText1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSearch1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        logs_tab.addTab("Manage Checkout", jPanel2);

        log_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Date", "Time", "Action"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(log_table);
        if (log_table.getColumnModel().getColumnCount() > 0) {
            log_table.getColumnModel().getColumn(0).setResizable(false);
            log_table.getColumnModel().getColumn(1).setResizable(false);
        }

        btnRefreshLogs.setText("Refresh");
        btnRefreshLogs.addActionListener(this::btnRefreshLogsActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 910, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnRefreshLogs)
                .addGap(23, 23, 23))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnRefreshLogs)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        logs_tab.addTab("View Logs", jPanel4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logs_tab)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logs_tab, javax.swing.GroupLayout.Alignment.TRAILING)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void drop_roomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drop_roomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drop_roomActionPerformed

    private void btnAddRoomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddRoomActionPerformed
        addRoom();
    }//GEN-LAST:event_btnAddRoomActionPerformed

    private void btnRefreshRoomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshRoomActionPerformed
        refreshRoomTable();
    }//GEN-LAST:event_btnRefreshRoomActionPerformed

    private void btnRefreshLogsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshLogsActionPerformed
        loadLogs();
    }//GEN-LAST:event_btnRefreshLogsActionPerformed

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        // TODO add your handling code here:
        registerGuest();
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void roomRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomRefreshActionPerformed
        // TODO add your handling code here:
        loadAvailableRooms();
    }//GEN-LAST:event_roomRefreshActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        loadGuests(guest_table);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        loadGuests(guest_table_checkout);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnCheckoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCheckoutActionPerformed
        // TODO add your handling code here:
        checkout();
    }//GEN-LAST:event_btnCheckoutActionPerformed

    private void btnSearch1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearch1ActionPerformed
        // TODO add your handling code here:
        searchTable(guest_table_checkout, searchText1.getText().trim());
    }//GEN-LAST:event_btnSearch1ActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        // TODO add your handling code here:
        searchTable(guest_table, searchText.getText().trim());
    }//GEN-LAST:event_btnSearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddRoom;
    private javax.swing.JButton btnCheckout;
    private javax.swing.JButton btnRefreshLogs;
    private javax.swing.JButton btnRefreshRoom;
    private javax.swing.JButton btnRegister;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnSearch1;
    private com.toedter.calendar.JDateChooser checkin_date;
    private javax.swing.JComboBox<String> drop_room;
    private javax.swing.JTextField full_name;
    private javax.swing.JTable guest_table;
    private javax.swing.JTable guest_table_checkout;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable log_table;
    private javax.swing.JTabbedPane logs_tab;
    private javax.swing.JTextField phone_no;
    private javax.swing.JTextField rent;
    private javax.swing.JButton roomRefresh;
    private javax.swing.JTextField room_no;
    private javax.swing.JTable room_table;
    private javax.swing.JTextField searchText;
    private javax.swing.JTextField searchText1;
    // End of variables declaration//GEN-END:variables
}
