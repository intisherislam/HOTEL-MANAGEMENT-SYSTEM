-- Create database if not exists
CREATE DATABASE IF NOT EXISTS hotel_db;
USE hotel_db;

-- Create user table if not exists
CREATE TABLE IF NOT EXISTS `user` (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'manager', 'staff') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert admin user if not exists
INSERT INTO `user` (fullname, username, password, role)
SELECT 'admin', 'admin', 'admin', 'admin'
FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM `user` WHERE username = 'admin'
);

-- Create rooms table if not exists
CREATE TABLE IF NOT EXISTS rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_no VARCHAR(50) NOT NULL UNIQUE,
    rent_per_night DECIMAL(10, 2) NOT NULL,
    status ENUM('available', 'occupied') DEFAULT 'available'
);

-- Create guests table if not exists
CREATE TABLE IF NOT EXISTS guests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(255) NOT NULL,
    room_no VARCHAR(50) NOT NULL,
    phone_no VARCHAR(50),
    checkin_date DATE NOT NULL,
    checkout_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_no) REFERENCES rooms (room_no)
);

-- Create logs table if not exists
CREATE TABLE IF NOT EXISTS logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    log_date DATE NOT NULL,
    log_time TIME NOT NULL,
    action VARCHAR(255) NOT NULL
);

